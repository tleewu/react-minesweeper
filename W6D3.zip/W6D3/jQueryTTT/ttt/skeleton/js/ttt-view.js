(function () {
  if (typeof TTT === "undefined") {
    window.TTT = {};
  }

  // var game = require("../ttt-core-solution/ttt-core.js");

  var View = TTT.View = function (game, $el) {
    this.game = game;
    this.$gameEl = $el;
    this.setupBoard();
    this.bindEvents();
  };

  View.prototype.bindEvents = function () {
    $("ul").on("click", function(e){
      var targetLi = $(e.target);
      this.makeMove(targetLi);
    }.bind(this));
  };

  View.prototype.makeMove = function ($square) {
    var player = this.game.currentPlayer;
    try{
      this.game.playMove($square.data("pos"));
    }
    catch(err){
      alert("Invalid Move!");
    }
    console.log(player);
    $square.html(player);
    $square.addClass(player);
    var winner = this.game.winner();
    console.log(winner);
    if(winner) {
      // if(winner == "o") {
      //   var loser = "x"
      // } else {
      //   var loser = "o"
      // }
      var $winningLis = this.$gameEl.find("."+winner)
      $winningLis.addClass('winner');
      // var $losingLis = this.$gameEl.find("."+loser)
      // $losingLis.addClass('loser');
      this.$gameEl.addClass('over');
      $("ul").off("click");
      var $h2 = $("<h2 class='overText'>");
      $h2.html("Winner is " + winner);
      this.$gameEl.append($h2);
    } else if (this.game.isOver()) {
      this.$gameEl.addClass('over');
      $("ul").off("click");
      var $h2 = $("<h2 class='overText'>");
      $h2.html("Draw");
      this.$gameEl.append($h2);
    }


  };

  View.prototype.setupBoard = function () {
    var $ul = $("<ul class='cf'></ul>");
    for(var x = 0; x < 3; x++) {
      for(var y = 0; y < 3; y++){
        var $li = $('<li></li>');
        $li.data("pos", [x, y])
        $ul.append($li);
      }
    }
    this.$gameEl.append($ul);
  };


})();
