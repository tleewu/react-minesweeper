# w5d5/w6d3: ttt.js

* **[w5d5 description][w5d5-description]**
* **[w6d3 description][w6d3-description]**
* **[Live Demo][live-demo]**

[w5d5-description]: https://github.com/appacademy/js-curriculum/blob/master/w5d5/hanoi-ttt.md
[w6d3-description]: https://github.com/appacademy/js-curriculum/blob/master/projects/w6d3-ttt-ui.md
[live-demo]: http://appacademy.github.io/ttt.js/solution/html/index.html
