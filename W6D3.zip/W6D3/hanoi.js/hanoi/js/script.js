(function() {
  if (typeof window.Hanoi === 'undefined') {
    window.Hanoi = {};
  }

  var View = Hanoi.View = function (game, $element) {
    this.game = game;
    this.$element = $element;
    this.setupColumns();
    this.render();
    this.clickTower();
  }

  View.prototype.clickTower = function() {
    $('.tower').on('click', function(e) {
      if (this.clickedTower === undefined) {
        this.clickedTower = $(e.target).data('tower-num');
        $(e.target).addClass('clickedTower');
      } else {
        var firstClick = this.clickedTower;
        var secondClick = $(e.target).data('tower-num');
        this.clickedTower = undefined;
        $(".clickedTower").removeClass('clickedTower');
        this.makeMove(firstClick, secondClick);
      }
    }.bind(this))
  };

  View.prototype.makeMove = function (fromTower, toTower) {
      if (this.game.move(fromTower, toTower)) {
        this.render();
      } else {
        alert("Move is invalid");
      }
      if(this.game.isWon()) {
        $('.disk').not('.empty').addClass("win")
        $('.tower').off('click');
        alert("Congrats you won!");
      }
  };
  View.prototype.render = function(){
    var gameState = this.game.towers;
    var $towers = $('.tower');
    for (var i = 0; i < $towers.length; i++) {
      var $tower = $($towers[i])
      $tower.empty();
      for(var j = 2; j >= 0 ; j--) {
        switch(gameState[i][j]) {
          case 1:
            var $disk = $('<div class="disk small">');
            break;
          case 2:
            var $disk = $('<div class="disk medium">');
            break;
          case 3:
            var $disk = $('<div class="disk large">');
            break;

          default:
            var $disk = $('<div class="disk empty">');
            break;
        }
        $disk.data('disk-size', gameState[i][j]);
        $tower.append($disk);
      }
    }
  }

  View.prototype.setupColumns = function () {
    for (var i = 0; i < 3; i++) {
      var $div = $('<div class="tower">');
      $div.data('tower-num', i);
      this.$element.append($div);
    }
  };
}())
