// index.js is probably overkill in this example; would make more sense
// if there were more source files.

module.exports = {
  Game: require("./game")
};
